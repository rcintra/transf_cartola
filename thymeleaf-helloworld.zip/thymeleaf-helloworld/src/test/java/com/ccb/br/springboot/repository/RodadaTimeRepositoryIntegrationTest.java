package com.ccb.br.springboot.repository;

import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.ccb.br.springboot.domain.RodadaTime;

@RunWith(SpringRunner.class)
@DataJpaTest
public class RodadaTimeRepositoryIntegrationTest {

	@Autowired
	private RodadaTimeRepository repository;
	
	@Test
	public void valid_query() {
		List<RodadaTime> classificacao = repository.findAll();
		for (RodadaTime rt : classificacao) {
			System.out.println(rt.getTime() + " | " + rt.getPontos() + " | " + rt.getTotal());
		}
	}
}
