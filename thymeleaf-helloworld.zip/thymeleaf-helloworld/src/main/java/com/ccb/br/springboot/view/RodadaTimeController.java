package com.ccb.br.springboot.view;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ccb.br.springboot.domain.Grupo;
import com.ccb.br.springboot.domain.RodadaTime;
import com.ccb.br.springboot.dto.ClassificacaoGrupoDto;
import com.ccb.br.springboot.dto.RodadaDto;
import com.ccb.br.springboot.repository.GrupoRepository;
import com.ccb.br.springboot.repository.RodadaRepository;
import com.ccb.br.springboot.repository.RodadaTimeRepository;
import com.ccb.br.springboot.repository.TimeRepository;
import com.ccb.br.springboot.service.RodadaService;
import com.ccb.br.springboot.view.form.RodadaTimeForm;

@Controller
@RequestMapping("/rodada")
public class RodadaTimeController {

	@Autowired
	private RodadaTimeRepository repository;
	
	@Autowired
	private RodadaRepository rodadaRepository;
	
	@Autowired
	private TimeRepository timeRepository;
	
	@Autowired
	private RodadaService rodadaService;
	
	@Autowired
	private GrupoRepository grupoRepository;
	
	@GetMapping( {"/rodada_time", "/rodada_time/index", "/rodada_time/home"})
	public ModelAndView rodadaTime() {
		
		ModelAndView model = new ModelAndView("rodada/rodada_time");
		
		List<Integer> rodadas = rodadaRepository.findIdAll();
		List<Grupo> grupos = grupoRepository.findAll();
		
		model.addObject("qtdRodadas", rodadas.size());
		model.addObject("rodadas", rodadaRepository.findAll());
		model.addObject("rodadasTimes", repository.consultarRodadaTimeByRodadas(rodadas));
		model.addObject("classificacao", rodadaService.consultarClassificacao(grupos));
		
		return model;
	}
	
	@GetMapping("/rodada_time/add")
	public ModelAndView add(RodadaTimeForm form, ModelMap modelMap) {
		
		ModelAndView model = new ModelAndView("rodada/add_rodada_time");
		
		model.addObject("rodadaTimeForm", form);
		model.addObject("rodadas", rodadaRepository.findAll());
		model.addObject("times", timeRepository.findAll());
		model.addObject("messageSuccess", modelMap.get("messageSuccess"));
		
		return model;
	}
	
	@PostMapping("/rodada_time/save")
	public ModelAndView save(@Valid RodadaTimeForm form, BindingResult result) {
		ModelMap modelMap = new ModelMap();
		if(result.hasErrors()) {
			return add(form, modelMap);
		}
		
		repository.save(converterFormToEntity(form));
		
		modelMap.addAttribute("messageSuccess", "Pontos incluido com sucesso.");
		
		return add(form, modelMap);
	}
	
	@GetMapping("/rodada_time/delete/{id}")
	public ModelAndView delete(@PathVariable("id") Integer id) {
		repository.delete(id);
		return rodadaTime();
	}
	
	@GetMapping("/rodada_time/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Integer id) {
		return add(converterEntityToForm(repository.findOne(id)), new ModelMap());
	}
	
	private RodadaTime converterFormToEntity(RodadaTimeForm form) {
		RodadaTime r = new RodadaTime();
		if (form.getId() != null)
			r = repository.findOne(form.getId());
		r.setRodada(rodadaRepository.findOne(form.getRodadaId()));
		r.setTime(timeRepository.findOne(form.getTimeId()));
		r.setPontos(form.getPontos());
		return r;
	}
	
	private RodadaTimeForm converterEntityToForm(RodadaTime rodadaTime) {
		RodadaTimeForm form = new RodadaTimeForm();
		form.setId(rodadaTime.getId());
		form.setRodadaId(rodadaTime.getRodada().getId());
		form.setTimeId(rodadaTime.getTime().getId());
		form.setPontos(rodadaTime.getPontos());
		return form;
	}
	
}
