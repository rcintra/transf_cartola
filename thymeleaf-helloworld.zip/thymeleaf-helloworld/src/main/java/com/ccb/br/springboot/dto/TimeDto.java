package com.ccb.br.springboot.dto;

import com.ccb.br.springboot.domain.Time;

public class TimeDto {

	private Integer id;
	private String nome;
	private String nomeTime;
	private String slug;
	private Integer timeId;
	
	public TimeDto() {}
	
	public TimeDto(Integer id, String nome, String nomeTime, String slug, Integer timeId) {
		this.id = id;
		this.nome = nome;
		this.nomeTime = nomeTime;
		this.slug = slug;
		this.timeId = timeId;
	}

	public TimeDto(Time time) {
		this(time.getId(), time.getNome(), time.getNomeTime(), time.getSlug(), time.getTimeId());
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNomeTime() {
		return nomeTime;
	}

	public void setNomeTime(String nomeTime) {
		this.nomeTime = nomeTime;
	}

	public String getSlug() {
		return slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}

	public Integer getTimeId() {
		return timeId;
	}

	public void setTimeId(Integer timeId) {
		this.timeId = timeId;
	}
	
}
