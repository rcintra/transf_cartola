package com.ccb.br.springboot.runner;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.ccb.br.springboot.domain.Campeonato;
import com.ccb.br.springboot.domain.Grupo;
import com.ccb.br.springboot.domain.Rodada;
import com.ccb.br.springboot.domain.Time;
import com.ccb.br.springboot.json.TimeDeserializer;
import com.ccb.br.springboot.repository.CampeonatoRepository;
import com.ccb.br.springboot.repository.GrupoRepository;
import com.ccb.br.springboot.repository.RodadaRepository;
import com.ccb.br.springboot.repository.RodadaTimeRepository;
import com.ccb.br.springboot.service.TimeService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class InitDbRunner implements CommandLineRunner {
	
    private static final Logger logger = LoggerFactory.getLogger(InitDbRunner.class);
	
	@Autowired
	private TimeService timeService;
	
	@Autowired
	private GrupoRepository grupoRepository;
	
	@Autowired
	private CampeonatoRepository campeonatoRepository;
	
	@Autowired
	private RodadaRepository rodadaRepository;
	
	@Autowired
	private RodadaTimeRepository rodadaTimeRepository;

	@Override
	public void run(String... arg0) throws Exception {
		//initCampeonato();
		//initGrupo();
		//initTime();
		//initRodada();
	}
	
	private void initCampeonato() {
		logger.info("Init Campeonato");
		
		campeonatoRepository.deleteAll();
		campeonatoRepository.save(new Campeonato("21º Osvaldo Cruz Eliminated of Cartola"));
		
	}
	
	private void initGrupo() {
		logger.info("Init Grupo");
		
		grupoRepository.deleteAll();
		
		grupoRepository.save(new Grupo("Grupo 1"));
		grupoRepository.save(new Grupo("Grupo 2"));
		grupoRepository.save(new Grupo("Grupo 3"));
		grupoRepository.save(new Grupo("Grupo 4"));
		
		/*cityRepository.findAll().forEach((city) -> {
            logger.info("{}", city);
        });*/
		
	}
	
	private void initTime() {
		logger.info("Init Times");
		
		ObjectMapper mapper = new ObjectMapper();
		TypeReference<List<TimeDeserializer>> typeReference = new TypeReference<List<TimeDeserializer>>(){};
		InputStream inputStream = TypeReference.class.getResourceAsStream("/json/times.json");
		try {
			List<TimeDeserializer> times = mapper.readValue(inputStream, typeReference);
			timeService.save(times.stream().map(t -> new Time(t)).collect(Collectors.toList()));
			logger.info("Times Saved!");
		} catch (IOException e) {
			logger.error("Unable to save times", e);
		}
		
	}
	
	private void initRodada() {
		logger.info("Init Rodadas");
		
		rodadaTimeRepository.deleteAll();
		rodadaRepository.deleteAll();
		
		rodadaRepository.save(new Rodada("1 Rodada", 1, 8));
		rodadaRepository.save(new Rodada("2 Rodada", 2, 9));
		rodadaRepository.save(new Rodada("3 Rodada", 3, 10));
		
	}
	
}
