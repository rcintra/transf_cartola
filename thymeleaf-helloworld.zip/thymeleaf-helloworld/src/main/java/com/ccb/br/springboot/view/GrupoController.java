package com.ccb.br.springboot.view;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ccb.br.springboot.domain.Grupo;
import com.ccb.br.springboot.repository.GrupoRepository;

@Controller
@RequestMapping("/grupo")
public class GrupoController {
	
	private GrupoRepository repository;
	
	public GrupoController(GrupoRepository repository) {
		this.repository = repository;
	}
	
	@GetMapping({"/home", "/index"})
	public ModelAndView index() {
		
		ModelAndView model = new ModelAndView("grupo/index");
		
		model.addObject("grupos", repository.findAll());
		
		return model;
	}
	
	@GetMapping("/add")
	public ModelAndView add(Grupo grupo) {
		
		ModelAndView model = new ModelAndView("grupo/add");
		model.addObject("grupo", grupo);
		
		return model;
	}
	
	@PostMapping("/save")
	public ModelAndView save(@Valid Grupo grupo, BindingResult result) {
		
		if(result.hasErrors()) {
			return add(grupo);
		}
		
		repository.save(grupo);
		
		return index();
	}
	
	@GetMapping("/delete/{id}")
	public ModelAndView delete(@PathVariable("id") Integer id) {
		
		repository.delete(id);
		
		return index();
	}
	
	@GetMapping("/edit/{id}")
	public ModelAndView edit(@PathVariable("id") Integer id) {
		
		return add(repository.findOne(id));
	}

}
