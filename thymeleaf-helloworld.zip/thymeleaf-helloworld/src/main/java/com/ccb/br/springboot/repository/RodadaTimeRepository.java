package com.ccb.br.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ccb.br.springboot.domain.RodadaTime;
import com.ccb.br.springboot.dto.RodadaDto;

public interface RodadaTimeRepository extends JpaRepository<RodadaTime, Integer> {

	@Query("select rt from RodadaTime rt where rt.rodada.id in (:rodadas)")
	List<RodadaTime> consultarRodadaTimeByRodadas(@Param("rodadas") List<Integer> rodadas);
	
	@Query("select rt from RodadaTime rt where rt.time.id in (:times)")
	List<RodadaTime> consultarRodadaTimeByTimes(@Param("times") List<Integer> times);
	
	@Query("select new com.ccb.br.springboot.dto.RodadaDto(rt.rodada.id, rt.rodada.nome, rt.pontos) from RodadaTime rt where rt.time.id = :time order by rt.rodada.id")
	List<RodadaDto> consultarRodadasByTime(@Param("time") Integer time);
}
