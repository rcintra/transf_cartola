package com.ccb.br.springboot.view;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import com.ccb.br.springboot.domain.Campeonato;
import com.ccb.br.springboot.repository.CampeonatoRepository;

@Controller
public class IndexController {
	
	@Autowired
	private CampeonatoRepository campeonatoRepository;

	@GetMapping( {"/", "/index"} )
	public ModelAndView index(HttpSession session) {
		ModelAndView model = new ModelAndView("/index");
		session.setAttribute("campeonatos", campeonatoRepository.findAll());
		return model;
	}
	
	@GetMapping("/selecionarCampeonato/{id}")
	public ModelAndView selecionarGrupo(@PathVariable("id") Integer id, HttpSession session) {
		Campeonato campeonato = campeonatoRepository.findOne(id);
		session.setAttribute("campeonato", campeonato);
		return index(session);
	}

}
