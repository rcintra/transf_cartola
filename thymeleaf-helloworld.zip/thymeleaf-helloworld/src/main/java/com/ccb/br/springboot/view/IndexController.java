package com.ccb.br.springboot.view;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.ccb.br.springboot.domain.Campeonato;
import com.ccb.br.springboot.repository.CampeonatoRepository;

@Controller
public class IndexController {
	
	@Autowired
	private CampeonatoRepository campeonatoRepository;

	@GetMapping( {"/", "/index"} )
	public String index(Model model, HttpSession session) {
		if (session.getAttribute("campeonato") != null) {
			session.setAttribute("campeonatos", campeonatoRepository.findAll());
			return "/index";
		}
		model.addAttribute("campeonato", new Campeonato());
		model.addAttribute("campeonatos", campeonatoRepository.findAll());
		return "/login/index";
	}
	
	@GetMapping("/selecionarCampeonato/{id}")
	public String selecionarGrupo(Model model, @PathVariable("id") Integer id, HttpSession session) {
		Campeonato campeonato = campeonatoRepository.findOne(id);
		session.setAttribute("campeonato", campeonato);
		return index(model, session);
	}

}
