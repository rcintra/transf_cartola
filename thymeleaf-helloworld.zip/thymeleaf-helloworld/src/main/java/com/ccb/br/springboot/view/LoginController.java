package com.ccb.br.springboot.view;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ccb.br.springboot.domain.Campeonato;
import com.ccb.br.springboot.repository.CampeonatoRepository;

@Controller
@RequestMapping("/login")
public class LoginController {
	
	@Autowired
	private CampeonatoRepository campeonatoRepository;

	@GetMapping({"/home", "/index"})
	public String index(Model model) {
        model.addAttribute("campeonato", new Campeonato());
		model.addAttribute("campeonatos", campeonatoRepository.findAll());
		return "/login/index";
	}
	
	
	@PostMapping("/sign")
    public String sign(@ModelAttribute Campeonato campeonato, HttpSession session) {
		session.setAttribute("campeonato", campeonato);
		session.setAttribute("campeonatos", campeonatoRepository.findAll());
        return "index";
    }
	
	@GetMapping("/logout")
	public String logout(Model model, HttpSession session) {
		session.removeAttribute("campeonato");
		return index(model);
	}
	
}
