package com.ccb.br.springboot.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ccb.br.springboot.domain.Rodada;

public interface RodadaRepository extends JpaRepository<Rodada, Integer> {

	Rodada findByNome(String nome);
	
	@Query("select r.id from Rodada r")
	List<Integer> findIdAll();

}
