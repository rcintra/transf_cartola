package com.ccb.br.springboot.dto;

import java.util.List;

public class ClassificacaoDto {
	
	public List<ClassificacaoGrupoDto> classificacaoGrupo;
	
	public ClassificacaoDto() {}
	
	public ClassificacaoDto(List<ClassificacaoGrupoDto> classificacaoGrupo) {
		this.classificacaoGrupo = classificacaoGrupo;
	}

	public List<ClassificacaoGrupoDto> getClassificacaoGrupo() {
		return classificacaoGrupo;
	}

	public void setClassificacaoGrupo(List<ClassificacaoGrupoDto> classificacaoGrupo) {
		this.classificacaoGrupo = classificacaoGrupo;
	}
	
}
