package com.ccb.br.springboot.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ClassificacaoGrupoDto {

	private String grupo;
	private Integer classificacao;
	private String nome;
	private List<RodadaDto> rodadas = new ArrayList<RodadaDto>();
	private BigDecimal total;
	
	public String getGrupo() {
		return grupo;
	}
	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}
	public Integer getClassificacao() {
		return classificacao;
	}
	public void setClassificacao(Integer classificacao) {
		this.classificacao = classificacao;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public List<RodadaDto> getRodadas() {
		return rodadas;
	}
	public void setRodadas(List<RodadaDto> rodadas) {
		this.rodadas = rodadas;
	}
	public BigDecimal getTotal() {
		return total;
	}
	public void setTotal(BigDecimal total) {
		this.total = total;
	}
}
